Redux Framework options panel for SeventhQueen Framework.
See contribution guide when updating the library.